#10/20
cnt=int(input())
for num in range(cnt):
    data = input()
    L=int(data[0])
    T1=data[1]
    T2=data[2]
    for j in range(1,L+1):
        print(T1*j,end="")
        for k in range(L-j):
            print(T2,end="")
        print()