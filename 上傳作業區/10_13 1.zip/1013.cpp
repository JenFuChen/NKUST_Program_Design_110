#include<iostream>
using namespace std;

#define MAX_LENGTH 100
#define NUM_STRINGS 10
int main(){
    int list[6],num1[10];
    int A,B,C,D,E,S;
    char rank1[NUM_STRINGS][MAX_LENGTH] = {"S", "A","B","C","D","E"};
    for(int i = 0; i<10;i++){
        scanf("%d",&num1[i]);
    }
    for(int i =0;i <10;i++){
        if (num1[i]==100) list[0]++;
        else if(num1[i]>=90 && num1[i] < 100) list[1]++;
        else if(num1[i]>=80 && num1[i] < 90) list[2]++;
        else if(num1[i]>=70 && num1[i] < 80)  list[3]++;
        else if(num1[i]>=60 && num1[i] < 70)  list[4]++;
        else if(num1[i]<60)  list[5]++;
    }
    for(int i = 0; i<6;i++){
        printf("%d%s\n",list[i],rank1[i]);
    }
    return 0;
}