//０５
#include <stdio.h>
#include <iostream>
using namespace std;
int main() {
    int cnt = 0;
    scanf("%d", &cnt);
    while (cnt != 0) {
        int mod = 0, num1 = 0, num2 = 0, sum = 0, moti = 1, min = 0, max = 0;
        scanf("%d%d%d", &mod, &num1, &num2);
        if (num1 > num2) {
            max = num1;
            min = num2;
        } else if (num2 > num1) {
            max = num2;
            min = num1;
        }
        if (mod == 1) {
            for (int i = min; i <= max; i++) {
                sum = sum + i;
            }
            printf("%d\n", sum);
        } else if (mod == 2) {
            for (int i = min; i <= max; i++) {
                moti = moti * i;
            }
            printf("%d\n", moti);
        }
        cnt--;
    }
    return 0;
}