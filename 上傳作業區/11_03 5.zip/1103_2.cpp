// 06 最大公因數
#include <stdio.h>
#include <algorithm>
#include <iostream>
using namespace std;
int main() {
    int list[3];
    for (int i = 0; i < 3; i++) {
        scanf("%d", &list[i]);
    }
    sort(list, list + 3);
    for (int i = 1; i <= list[2]; i++) {
        if (list[0] % i == 0 && list[1] % i == 0 && list[2] % i == 0) {
            if (list[0] == 0) {
                printf("%d\n", i);
            }
            list[0] = list[0] % i;
        }
    }
}