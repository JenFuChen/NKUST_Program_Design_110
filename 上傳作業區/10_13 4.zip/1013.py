import numpy as np
letters = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
            'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
times = np.zeros(52,dtype=int)
a=0
for i in range(3):
    sentence = input()
    for i in range(0,52):
        a = int(sentence.count(letters[i]))
        times[i] = a
        a=0

    cnt = 0

    for i in range(0,52):
        cnt = int(times[i])
        if cnt!= 0:
            print(letters[i],end = "")
            for i in range(0,cnt):
                print("*",end = "")
    print()